/**
 * CaptureIQ — Background Service Worker
 * Handles: Google OAuth, context menus, API calls, event creation
 */

const API_BASE = 'http://localhost:3001/api';
const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';

// ── Context Menu Setup ─────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'captureiq-capture',
    title: '✦ Capture with CaptureIQ',
    contexts: ['selection'],
  });
  chrome.contextMenus.create({
    id: 'captureiq-page',
    title: '✦ Capture entire page info',
    contexts: ['page'],
  });
  console.log('[CaptureIQ] Extension installed and context menus created');
});

// ── Context Menu Click Handler ─────────────────────────────
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const text = info.selectionText || '';
  const pageUrl = tab?.url || '';
  const pageTitle = tab?.title || '';

  if (info.menuItemId === 'captureiq-capture' && text) {
    await processCapture({ text, pageUrl, pageTitle, source: 'context_menu' });
  } else if (info.menuItemId === 'captureiq-page') {
    // Inject script to get page text
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => document.body.innerText.slice(0, 3000),
    });
    if (result?.result) {
      await processCapture({ text: result.result, pageUrl, pageTitle, source: 'full_page' });
    }
  }
});

// ── Message Handler (from content script / popup) ─────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'CAPTURE_TEXT':
      processCapture({
        text: message.text,
        pageUrl: message.pageUrl || sender.tab?.url || '',
        pageTitle: message.pageTitle || sender.tab?.title || '',
        source: message.source || 'manual',
      }).then(sendResponse);
      return true; // Keep channel open for async

    case 'GET_AUTH_STATUS':
      getAuthStatus().then(sendResponse);
      return true;

    case 'SIGN_IN':
      signInWithGoogle().then(sendResponse);
      return true;

    case 'SIGN_OUT':
      signOut().then(sendResponse);
      return true;

    case 'GET_RECENT_CAPTURES':
      getRecentCaptures().then(sendResponse);
      return true;

    case 'OPEN_DASHBOARD':
      chrome.tabs.create({ url: 'http://localhost:5500/dashboard/' });
      sendResponse({ success: true });
      break;
  }
});

// ── Core: Process a capture ────────────────────────────────
async function processCapture({ text, pageUrl, pageTitle, source }) {
  try {
    // Show processing notification
    showNotification('processing', 'CaptureIQ Processing…', 'AI is analyzing your captured text');

    // Get auth token
    const token = await getStoredToken();
    if (!token) {
      showNotification('error', 'Sign in Required', 'Please sign in with Google to use CaptureIQ');
      return { success: false, error: 'not_authenticated' };
    }

    // Send to backend AI for parsing
    const response = await fetch(`${API_BASE}/capture/process`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ text, pageUrl, pageTitle, source }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || `HTTP ${response.status}`);
    }

    const result = await response.json();

    if (result.intent === 'calendar_event' && result.event) {
      // Auto-create in Google Calendar
      const calResult = await createCalendarEvent(result.event, token);

      showNotification(
        'success',
        '✓ Event Created!',
        `"${result.event.title}" added to Google Calendar`
      );

      // Notify content script to show toast
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab) {
        chrome.tabs.sendMessage(activeTab.id, {
          type: 'SHOW_TOAST',
          message: `✓ Event created: "${result.event.title}"`,
          eventLink: calResult?.htmlLink,
        }).catch(() => {}); // Ignore if tab has no content script
      }

      return { success: true, event: result.event, calendarLink: calResult?.htmlLink };
    } else if (result.intent === 'task') {
      showNotification('success', '✓ Task Created!', `"${result.task?.title}" added to your tasks`);
      return { success: true, task: result.task };
    } else {
      showNotification('info', 'Captured!', result.summary || 'Text captured and saved');
      return { success: true, summary: result.summary };
    }
  } catch (err) {
    console.error('[CaptureIQ] processCapture error:', err.message);
    showNotification('error', 'Capture Failed', err.message);
    return { success: false, error: err.message };
  }
}

// ── Google Calendar: Create Event ─────────────────────────
async function createCalendarEvent(event, authToken) {
  const userToken = await getGoogleOAuthToken();
  if (!userToken) throw new Error('Google OAuth token not available');

  const body = {
    summary: event.title,
    description: event.description || `Created by CaptureIQ\nSource: ${event.sourceUrl || ''}`,
    location: event.location || '',
    start: event.allDay
      ? { date: event.startDate }
      : { dateTime: event.startDateTime, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone },
    end: event.allDay
      ? { date: event.endDate || event.startDate }
      : { dateTime: event.endDateTime, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone },
    attendees: (event.attendees || []).map(e => ({ email: e })),
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'popup', minutes: 30 },
        { method: 'email', minutes: 60 },
      ],
    },
  };

  const res = await fetch(
    'https://www.googleapis.com/calendar/v3/calendars/primary/events?sendUpdates=all',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${userToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }
  );

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || 'Failed to create Google Calendar event');
  }

  return res.json();
}

// ── Google OAuth ───────────────────────────────────────────
async function signInWithGoogle() {
  try {
    const token = await new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true, scopes: [
        'https://www.googleapis.com/auth/calendar',
        'https://www.googleapis.com/auth/calendar.events',
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile',
      ]}, (token) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(token);
      });
    });

    // Get user profile
    const profileRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${token}` },
    });
    const profile = await profileRes.json();

    // Store token and profile
    await chrome.storage.local.set({
      googleToken: token,
      userProfile: { email: profile.email, name: profile.name, picture: profile.picture },
      signedIn: true,
    });

    // Sync with backend
    await syncWithBackend(token, profile);

    return { success: true, profile };
  } catch (err) {
    console.error('[CaptureIQ] Sign in failed:', err.message);
    return { success: false, error: err.message };
  }
}

async function signOut() {
  const { googleToken } = await chrome.storage.local.get('googleToken');
  if (googleToken) {
    await new Promise(resolve => chrome.identity.removeCachedAuthToken({ token: googleToken }, resolve));
  }
  await chrome.storage.local.clear();
  return { success: true };
}

async function getAuthStatus() {
  const data = await chrome.storage.local.get(['signedIn', 'userProfile']);
  return { signedIn: data.signedIn || false, profile: data.userProfile || null };
}

async function getStoredToken() {
  const { googleToken } = await chrome.storage.local.get('googleToken');
  return googleToken || null;
}

async function getGoogleOAuthToken() {
  return new Promise((resolve) => {
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      resolve(chrome.runtime.lastError ? null : token);
    });
  });
}

// ── Sync with backend ──────────────────────────────────────
async function syncWithBackend(token, profile) {
  try {
    await fetch(`${API_BASE}/auth/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ email: profile.email, name: profile.name, picture: profile.picture }),
    });
  } catch { /* Backend offline, non-fatal */ }
}

// ── Recent captures ────────────────────────────────────────
async function getRecentCaptures() {
  try {
    const token = await getStoredToken();
    if (!token) return { captures: [] };
    const res = await fetch(`${API_BASE}/capture/recent?limit=10`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.ok ? res.json() : { captures: [] };
  } catch { return { captures: [] }; }
}

// ── Notifications ──────────────────────────────────────────
function showNotification(type, title, message) {
  const icons = { success: 'icons/icon48.png', error: 'icons/icon48.png', processing: 'icons/icon48.png', info: 'icons/icon48.png' };
  chrome.notifications.create(`captureiq-${Date.now()}`, {
    type: 'basic',
    iconUrl: icons[type] || icons.info,
    title,
    message,
    priority: type === 'error' ? 2 : 1,
  });
}
