/**
 * CaptureIQ — Content Script
 * Detects text selection and shows a floating capture toolbar
 */

(function () {
  'use strict';

  if (window.__captureIQLoaded) return;
  window.__captureIQLoaded = true;

  let toolbar = null;
  let captureToast = null;
  let selectionTimeout = null;

  // ── Create the floating toolbar ───────────────────────────
  function createToolbar() {
    const el = document.createElement('div');
    el.id = 'captureiq-toolbar';
    el.innerHTML = `
      <div class="ciq-toolbar-inner">
        <div class="ciq-brand">
          <span class="ciq-dot"></span>
          <span class="ciq-label">CaptureIQ</span>
        </div>
        <div class="ciq-actions">
          <button class="ciq-btn ciq-btn-primary" id="ciq-capture-btn" title="Capture as Calendar Event">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            <span>Capture Event</span>
          </button>
          <button class="ciq-btn ciq-btn-secondary" id="ciq-task-btn" title="Save as Task">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 11l3 3L22 4"/></svg>
            <span>Task</span>
          </button>
          <button class="ciq-close" id="ciq-close-btn">✕</button>
        </div>
        <div class="ciq-preview" id="ciq-preview"></div>
        <div class="ciq-status" id="ciq-status" style="display:none"></div>
      </div>
    `;
    document.body.appendChild(el);

    document.getElementById('ciq-capture-btn').addEventListener('click', handleCapture);
    document.getElementById('ciq-task-btn').addEventListener('click', handleTask);
    document.getElementById('ciq-close-btn').addEventListener('click', hideToolbar);

    return el;
  }

  // ── Show toolbar near selection ────────────────────────────
  function showToolbar(selectedText) {
    if (!toolbar) toolbar = createToolbar();

    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    // Position toolbar above selection
    const scrollX = window.scrollX, scrollY = window.scrollY;
    let top = rect.top + scrollY - 70;
    let left = rect.left + scrollX + rect.width / 2 - 160;

    // Keep within viewport
    if (top < scrollY + 10) top = rect.bottom + scrollY + 10;
    left = Math.max(scrollX + 8, Math.min(left, scrollX + window.innerWidth - 328));

    toolbar.style.top = `${top}px`;
    toolbar.style.left = `${left}px`;
    toolbar.style.display = 'block';

    // Show preview of selected text
    const preview = document.getElementById('ciq-preview');
    const truncated = selectedText.length > 80 ? selectedText.slice(0, 80) + '…' : selectedText;
    preview.textContent = `"${truncated}"`;

    // Reset status
    const status = document.getElementById('ciq-status');
    status.style.display = 'none';

    toolbar.dataset.selectedText = selectedText;
  }

  function hideToolbar() {
    if (toolbar) toolbar.style.display = 'none';
  }

  // ── Selection detection ────────────────────────────────────
  document.addEventListener('mouseup', (e) => {
    clearTimeout(selectionTimeout);

    // Don't trigger inside our own toolbar
    if (toolbar && toolbar.contains(e.target)) return;

    selectionTimeout = setTimeout(() => {
      const selection = window.getSelection();
      const text = selection?.toString().trim();

      if (text && text.length > 10) {
        showToolbar(text);
      } else {
        hideToolbar();
      }
    }, 200);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') hideToolbar();
  });

  document.addEventListener('scroll', hideToolbar, { passive: true });

  // ── Handle capture ─────────────────────────────────────────
  async function handleCapture() {
    const text = toolbar?.dataset.selectedText;
    if (!text) return;

    setStatus('loading', 'AI is processing…');

    const result = await chrome.runtime.sendMessage({
      type: 'CAPTURE_TEXT',
      text,
      pageUrl: window.location.href,
      pageTitle: document.title,
      source: 'selection',
    });

    if (result?.success) {
      setStatus('success', result.event
        ? `✓ Event created: "${result.event.title}"`
        : '✓ Captured successfully');
      setTimeout(hideToolbar, 2500);
    } else {
      setStatus('error', `✗ ${result?.error || 'Capture failed'}`);
    }
  }

  async function handleTask() {
    const text = toolbar?.dataset.selectedText;
    if (!text) return;

    setStatus('loading', 'Saving task…');

    const result = await chrome.runtime.sendMessage({
      type: 'CAPTURE_TEXT',
      text,
      pageUrl: window.location.href,
      pageTitle: document.title,
      source: 'task',
    });

    if (result?.success) {
      setStatus('success', '✓ Task saved!');
      setTimeout(hideToolbar, 2000);
    } else {
      setStatus('error', '✗ Failed to save task');
    }
  }

  function setStatus(type, message) {
    const btn = document.getElementById('ciq-capture-btn');
    const status = document.getElementById('ciq-status');
    status.style.display = 'block';
    status.className = `ciq-status ciq-status-${type}`;
    status.textContent = message;
    if (type === 'loading' && btn) btn.disabled = true;
    if ((type === 'success' || type === 'error') && btn) btn.disabled = false;
  }

  // ── Toast notification from background ────────────────────
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'SHOW_TOAST') {
      showPageToast(message.message, message.eventLink);
    }
  });

  function showPageToast(message, link) {
    if (captureToast) captureToast.remove();

    captureToast = document.createElement('div');
    captureToast.id = 'captureiq-toast';
    captureToast.innerHTML = `
      <div class="ciq-toast-inner">
        <span class="ciq-toast-icon">✓</span>
        <span class="ciq-toast-msg">${message}</span>
        ${link ? `<a class="ciq-toast-link" href="${link}" target="_blank">View →</a>` : ''}
        <button class="ciq-toast-close" onclick="this.parentNode.parentNode.remove()">✕</button>
      </div>
    `;
    document.body.appendChild(captureToast);
    setTimeout(() => captureToast?.remove(), 5000);
  }

})();
