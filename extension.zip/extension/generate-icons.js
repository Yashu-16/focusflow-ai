/**
 * CaptureIQ — Icon Generator
 * Run: node generate-icons.js
 * Creates placeholder PNG icons for the Chrome extension.
 * Replace with real icons in production.
 */

const fs = require('fs');
const path = require('path');

// We create minimal valid PNG files as placeholders.
// For production, use real icon files (16x16, 32x32, 48x48, 128x128).
// Tools: Figma, Photoshop, or free icon generators like https://realfavicongenerator.net

const sizes = [16, 32, 48, 128];
const iconsDir = path.join(__dirname, 'extension', 'icons');

if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir, { recursive: true });

// Create a minimal 1x1 transparent PNG and note that real icons are needed
const minimalPNG = Buffer.from(
  '89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489' +
  '0000000a49444154789c6260000000020001e221bc330000000049454e44ae426082',
  'hex'
);

sizes.forEach(size => {
  const filePath = path.join(iconsDir, `icon${size}.png`);
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, minimalPNG);
    console.log(`Created placeholder icon: icon${size}.png`);
  }
});

console.log('\n⚠️  These are placeholder icons. For production:');
console.log('   Replace with real PNG icons of sizes: 16, 32, 48, 128px');
console.log('   Design tip: Use the CaptureIQ layered stack logo on #00d4aa background\n');
