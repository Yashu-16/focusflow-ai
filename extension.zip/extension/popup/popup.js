'use strict';

const API_BASE = 'http://localhost:3001/api';

async function send(type, data = {}) {
  return chrome.runtime.sendMessage({ type, ...data });
}

async function init() {
  checkBackend();
  const auth = await send('GET_AUTH_STATUS');

  if (auth.signedIn && auth.profile) {
    showMainPanel(auth.profile);
    loadRecent();
  } else {
    showAuthPanel();
  }

  document.getElementById('btn-signin').addEventListener('click', handleSignIn);
  document.getElementById('btn-signout')?.addEventListener('click', handleSignOut);
  document.getElementById('btn-capture')?.addEventListener('click', handleCapture);
  document.getElementById('btn-dashboard')?.addEventListener('click', () => send('OPEN_DASHBOARD'));
  document.getElementById('capture-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.ctrlKey) handleCapture();
  });
}

function showAuthPanel() {
  document.getElementById('panel-auth').style.display = 'block';
  document.getElementById('panel-main').style.display = 'none';
}

function showMainPanel(profile) {
  document.getElementById('panel-auth').style.display = 'none';
  document.getElementById('panel-main').style.display = 'block';
  document.getElementById('user-name').textContent = profile.name || profile.email;
  document.getElementById('user-email').textContent = profile.email;
  const pic = document.getElementById('user-pic');
  if (profile.picture) pic.src = profile.picture;
  else pic.textContent = (profile.name || '?')[0].toUpperCase();
}

async function handleSignIn() {
  const btn = document.getElementById('btn-signin');
  btn.textContent = 'Signing in…';
  btn.disabled = true;
  const result = await send('SIGN_IN');
  if (result.success) {
    showMainPanel(result.profile);
    loadRecent();
  } else {
    btn.textContent = '✗ Failed — try again';
    btn.disabled = false;
  }
}

async function handleSignOut() {
  await send('SIGN_OUT');
  showAuthPanel();
}

async function handleCapture() {
  const input = document.getElementById('capture-input');
  const text = input.value.trim();
  if (!text) return;

  const btn = document.getElementById('btn-capture');
  const status = document.getElementById('capture-status');

  btn.disabled = true;
  setStatus('loading', '⏳ AI processing…');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const result = await send('CAPTURE_TEXT', {
    text,
    pageUrl: tab?.url || '',
    pageTitle: tab?.title || '',
    source: 'popup',
  });

  if (result?.success) {
    const msg = result.event
      ? `✓ Event created: "${result.event.title}"`
      : result.task
      ? `✓ Task saved: "${result.task?.title}"`
      : '✓ Captured!';
    setStatus('success', msg);
    input.value = '';
    loadRecent();
  } else {
    setStatus('error', `✗ ${result?.error || 'Failed'}`);
  }

  btn.disabled = false;
}

function setStatus(type, msg) {
  const el = document.getElementById('capture-status');
  el.style.display = 'block';
  el.className = `capture-status ${type}`;
  el.textContent = msg;
}

async function loadRecent() {
  const el = document.getElementById('recent-list');
  if (!el) return;

  const data = await send('GET_RECENT_CAPTURES');
  const captures = data?.captures || [];

  if (captures.length === 0) {
    el.innerHTML = '<div class="empty-msg">No captures yet — select text on any page!</div>';
    return;
  }

  el.innerHTML = captures.map(c => `
    <div class="recent-item">
      <div class="recent-title">${c.title || c.text?.slice(0, 50) || 'Capture'}</div>
      <div class="recent-meta">${new Date(c.createdAt).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</div>
      <span class="recent-type type-${c.type || 'note'}">${c.type || 'note'}</span>
    </div>
  `).join('');
}

async function checkBackend() {
  const dot = document.getElementById('conn-dot');
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (res.ok) { dot.classList.add('online'); dot.setAttribute('title', 'Backend online'); }
    else { dot.classList.add('offline'); }
  } catch {
    dot.classList.add('offline');
    dot.setAttribute('title', 'Backend offline');
  }
}

document.addEventListener('DOMContentLoaded', init);
